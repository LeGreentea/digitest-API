package com.polstatstis.digiexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DigiexamApplication {

	public static void main(String[] args) {
		SpringApplication.run(DigiexamApplication.class, args);
	}

}
